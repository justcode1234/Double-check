"""Read-only HTTP contracts and dependency-free dashboard behavior checks.

Every HTTP server uses an ephemeral loopback port and a temporary test ledger.
The Node harness exercises DOM updates; a real browser is still needed for visual QA.
"""
import csv
import hashlib
import http.client
import io
import json
from contextlib import contextmanager
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
import shutil
import socket
import sqlite3
import subprocess
import threading

import pytest

from dual_strategy.dashboard import server as dashboard_server
from dual_strategy.portfolio import ledger as ledger_module
from dual_strategy.portfolio.ledger import Ledger
from dual_strategy.reporting import service

ASSETS = Path(dashboard_server.__file__).parent
NOW = datetime(2026, 11, 17, 17, 0, tzinfo=timezone.utc)
AT = NOW.isoformat()
PRIVATE_MARKERS = ('private-account-9281', 'private-token-9281', 'private-order-9281', 'private-file-9281')


@pytest.fixture
def project(tmp_path, monkeypatch):
    monkeypatch.setattr(ledger_module, 'stamp', lambda: AT)
    (tmp_path / 'evidence').mkdir()
    (tmp_path / 'reports').mkdir()
    (tmp_path / 'private').mkdir()
    (tmp_path / 'private' / 'credentials.json').write_text('{"secret":"private-file-9281"}', encoding='utf-8')
    capabilities = {
        'candidate_broker_cash_usd': 1000000,
        'candidate_broker_nav_usd': 1000000,
        'broker_balance_changed': False,
        'order_count_this_experiment': 0,
        'user_authorized_shared_practice_account': True,
        'account_mode_requested': 'SHARED PRACTICE ACCOUNT — TWO VIRTUAL $50K SUB-LEDGERS',
        'account_id': PRIVATE_MARKERS[0],
        'nested': [{'oauth_token': PRIVATE_MARKERS[1]}],
        'blockers': ['Paper lifecycle and independent sentinel not verified'],
    }
    (tmp_path / 'evidence' / 'capabilities.json').write_text(json.dumps(capabilities), encoding='utf-8')
    (tmp_path / 'reports' / 'backtest_comparison.json').write_text(json.dumps({
        'label': 'TEST RESEARCH ONLY', 'nav': 999999, 'sharpe': 9.5,
        'secret': PRIVATE_MARKERS[1], 'benchmark': {'equity': [{'at': AT, 'nav': 999999}]},
    }), encoding='utf-8')
    db = tmp_path / 'ledger.sqlite3'
    ledger = Ledger(db)
    try:
        ledger.initialize('dashboard-test')
        ledger.append('orb', 'RISK_REJECTION', {
            'reason': 'No verified practice lifecycle',
            'account_id': PRIVATE_MARKERS[0],
            'nested': [{'broker_order_id': PRIVATE_MARKERS[2], 'token': PRIVATE_MARKERS[1], 'safe': 'kept'}],
            'untrusted': '<img src=x onerror=alert(1)>',
        }, 'dashboard-test', '=formula-test', AT)
    finally:
        ledger.close()
    return tmp_path, db


@contextmanager
def running_server(project, db):
    server = dashboard_server.create_server(project, db, port=0)
    thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': .01}, daemon=True)
    thread.start()
    try:
        yield server.server_address[1]
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)
        assert not thread.is_alive(), 'Test server did not shut down'


def test_dashboard_starts_without_reverse_dns(project, monkeypatch):
    def unexpected_lookup(*args):
        pytest.fail('Binding the loopback dashboard should not perform a DNS lookup')

    monkeypatch.setattr(socket, 'getfqdn', unexpected_lookup)
    with running_server(*project) as port:
        status, _, _ = request(port, '/api/launcher')
        assert status == 200


def request(port, path, method='GET', host=None, body=None, headers=None):
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=3)
    try:
        headers = dict(headers or {})
        if host:
            headers['Host'] = host
        connection.request(method, path, body=body, headers=headers)
        response = connection.getresponse()
        return response.status, dict(response.getheaders()), response.read().decode('utf-8')
    finally:
        connection.close()


@pytest.fixture
def endpoint(project, monkeypatch):
    root, db = project
    monkeypatch.setattr(dashboard_server, 'report_status', lambda db_path, project: service.report_status(db_path, project, NOW))
    with running_server(root, db) as port:
        yield port


def assert_safe_headers(headers, mime):
    assert headers['Content-Type'] == mime + '; charset=utf-8'
    assert headers['Cache-Control'] == 'no-store'
    assert headers['X-Content-Type-Options'] == 'nosniff'
    csp = headers['Content-Security-Policy']
    assert "script-src 'self'" in csp and "style-src 'self'" in csp
    assert "connect-src 'self'" in csp and "frame-ancestors 'none'" in csp
    assert 'unsafe-inline' not in csp and 'unsafe-eval' not in csp


def test_status_and_json_export_golden(endpoint):
    status, headers, body = request(endpoint, '/api/status')
    assert status == 200
    assert_safe_headers(headers, 'application/json')
    result = json.loads(body)
    assert result['generated_at'] == AT
    assert result['execution_enabled'] is False
    assert result['chain_verified'] is True
    assert result['event_count'] == 3
    assert [p['strategy'] for p in result['portfolios']] == ['orb', 'noise_area']
    expected = {
        'initial_nav': 50000, 'nav': 50000, 'cash': 50000, 'cash_available': 50000,
        'realized_pnl': 0, 'unrealized_pnl': 0, 'total_pnl': 0, 'return_pct': 0,
        'gross_exposure': 0, 'net_exposure': 0, 'reserved': 0, 'positions': [], 'trades': [],
        'paper_fill_count': 0, 'shadow_fill_count': 0, 'closed_trade_count': 0,
        'sample_sessions': 0, 'daily_loss_remaining': 625, 'daily_pnl': 0,
        'max_drawdown_pct': 0, 'order_count': 0, 'requested_shares': 0, 'filled_shares': 0,
        'fill_ratio_pct': None, 'win_rate_pct': None, 'average_win': None, 'average_loss': None,
        'expectancy_dollars': None, 'expectancy_r': None, 'profit_factor': None,
        'sharpe': None, 'sortino': None, 'fees': 0, 'broker_fees': None,
        'sentinel_status': 'NOT_RUNNING', 'sentinel_age_seconds': None,
        'feed_status': 'NOT_CONNECTED', 'mark_age_seconds': None, 'cloud_status': 'READ_ONLY_ROLES_DEPLOYED',
        'runtime': 'SHADOW', 'label': 'SHADOW / HYPOTHETICAL FILLS', 'emergency_stops': 0,
        'equity': [{'at': AT, 'nav': 50000, 'observation': False}],
        'drawdown_curve': [{'at': AT, 'drawdown_pct': 0}],
    }
    for p in result['portfolios']:
        assert {key: p[key] for key in expected} == expected
        assert p['risk_rejections'] == (1 if p['strategy'] == 'orb' else 0)
    assert result['research']['nav'] == 999999
    assert result['capabilities']['user_authorized_shared_practice_account'] is True
    assert result['capabilities']['broker_balance_changed'] is False
    assert result['audit'][-1]['payload']['nested'] == [{'safe': 'kept'}]
    for marker in PRIVATE_MARKERS:
        assert marker not in body
    status, headers, exported = request(endpoint, '/export/status.json')
    assert status == 200
    assert_safe_headers(headers, 'application/json')
    assert headers['Content-Disposition'] == 'attachment; filename="comparison.json"'
    assert json.loads(exported) == result


def test_csv_exports_golden_and_redacted(endpoint):
    status, headers, body = request(endpoint, '/export/equity.csv')
    assert status == 200
    assert_safe_headers(headers, 'text/csv')
    assert headers['Content-Disposition'] == 'attachment; filename="equity.csv"'
    assert list(csv.DictReader(io.StringIO(body))) == [
        {'strategy': strategy, 'at': AT, 'nav': '50000.0', 'observation': 'False'}
        for strategy in ('orb', 'noise_area')
    ]
    status, headers, body = request(endpoint, '/export/audit.csv')
    assert status == 200
    assert_safe_headers(headers, 'text/csv')
    assert headers['Content-Disposition'] == 'attachment; filename="audit.csv"'
    rows = list(csv.DictReader(io.StringIO(body)))
    assert [(r['sequence'], r['strategy'], r['kind']) for r in rows] == [
        ('1', 'orb', 'INITIAL_CAPITAL'), ('2', 'noise_area', 'INITIAL_CAPITAL'), ('3', 'orb', 'RISK_REJECTION')]
    assert rows[-1]['event_id'] == "'=formula-test"
    assert json.loads(rows[-1]['payload'])['nested'] == [{'safe': 'kept'}]
    for marker in PRIVATE_MARKERS:
        assert marker not in body


@pytest.mark.parametrize(('url', 'filename', 'mime'), [('/', 'index.html', 'text/html'), ('/app.js', 'app.js', 'text/javascript'), ('/style.css', 'style.css', 'text/css'),
                                                     ('/backtest', 'backtest.html', 'text/html'), ('/backtest.js', 'backtest.js', 'text/javascript'),
                                                     ('/backtest.css', 'backtest.css', 'text/css')])
def test_only_local_assets_are_served(endpoint, url, filename, mime):
    status, headers, body = request(endpoint, url)
    assert status == 200
    assert_safe_headers(headers, mime)
    assert body == (ASSETS / filename).read_text(encoding='utf-8')
    assert int(headers['Content-Length']) == len(body.encode('utf-8'))


@pytest.mark.parametrize('path', [
    '/private/credentials.json', '/../private/credentials.json', '/%2e%2e/private/credentials.json',
    '/%252e%252e/private/credentials.json', '/..%5cprivate%5ccredentials.json',
    '/src/dual_strategy/dashboard/server.py', '/server.py', '/index.html', '/api/orders',
    '/export/../../private/credentials.json', '/export/status.json/extra', '/api/status/../orders',
])
def test_unknown_paths_and_traversal_are_404(endpoint, path):
    status, _, body = request(endpoint, path)
    assert status == 404
    assert json.loads(body) == {'error': 'Not found'}
    for marker in PRIVATE_MARKERS:
        assert marker not in body


@pytest.mark.parametrize('method', ['POST', 'PUT', 'DELETE', 'PATCH'])
@pytest.mark.parametrize('path', ['/api/status', '/api/orders'])
def test_dashboard_rejects_mutations(endpoint, method, path):
    status, _, body = request(endpoint, path, method)
    assert status == 405
    assert json.loads(body) == {'error': 'Read-only dashboard'}


def test_non_loopback_host_is_rejected(endpoint):
    status, _, body = request(endpoint, '/api/status', host='attacker.example')
    assert status == 403
    assert json.loads(body) == {'error': 'Loopback host required'}


@pytest.mark.parametrize('path', ['/api/status', '/export/status.json', '/export/audit.csv', '/export/equity.csv'])
def test_missing_database_returns_503_without_creating_it(tmp_path, path):
    missing = tmp_path / 'missing.sqlite3'
    with running_server(tmp_path, missing) as port:
        status, headers, body = request(port, path)
        assert status == 503
        assert_safe_headers(headers, 'application/json')
        assert json.loads(body) == {'error': 'Ledger or evidence unavailable; execution remains disabled'}
        assert not missing.exists()
        assert request(port, '/')[0] == 200


def test_report_endpoints_open_ledger_read_only_and_do_not_mutate(project, endpoint, monkeypatch):
    _, db = project
    before = hashlib.sha256(db.read_bytes()).hexdigest()
    opens = []

    class ReadOnlyLedger(Ledger):
        def __init__(self, path, *, read_only=False):
            assert read_only is True, 'Dashboard attempted a writable database connection'
            super().__init__(path, read_only=read_only)
            opens.append(self.db.execute('PRAGMA query_only').fetchone()[0])
            with pytest.raises(sqlite3.OperationalError):
                self.db.execute("DELETE FROM events")

    monkeypatch.setattr(service, 'Ledger', ReadOnlyLedger)
    monkeypatch.setattr(dashboard_server, 'Ledger', ReadOnlyLedger)
    for path in ('/api/status', '/export/status.json', '/export/audit.csv', '/export/equity.csv'):
        assert request(endpoint, path)[0] == 200
    assert opens == [1] * 5
    assert hashlib.sha256(db.read_bytes()).hexdigest() == before


def test_failed_integrity_is_reported_not_repaired(project, endpoint, monkeypatch):
    _, db = project
    before = hashlib.sha256(db.read_bytes()).hexdigest()
    # Simulate a failed verification without bypassing append-only ledger triggers.
    monkeypatch.setattr(Ledger, 'verify_chain', lambda self: False)
    status, _, body = request(endpoint, '/api/status')
    assert status == 200
    assert json.loads(body)['chain_verified'] is False
    assert json.loads(body)['execution_enabled'] is False
    assert hashlib.sha256(db.read_bytes()).hexdigest() == before


def test_optional_evidence_can_be_absent(project, endpoint):
    root, _ = project
    (root / 'evidence' / 'capabilities.json').unlink()
    (root / 'reports' / 'backtest_comparison.json').unlink()
    status, _, body = request(endpoint, '/api/status')
    assert status == 200
    assert json.loads(body)['capabilities'] == {}
    assert json.loads(body)['research'] is None


@pytest.fixture
def control_project(project):
    from dual_strategy.risk.state_machine import RiskState, RuntimeState
    root, db = project
    (root / 'config').mkdir()
    for name in ('orb', 'noise_area', 'risk'):
        (root / 'config' / f'{name}.yaml').write_text('paper_execution_enabled: false\n', encoding='utf-8')
    ledger = Ledger(db)
    try:
        for strategy in ('orb', 'noise_area'):
            ledger.save_state(strategy, RiskState(strategy, runtime=RuntimeState.SHADOW).to_dict())
    finally:
        ledger.close()
    return root, db


def control_headers(port):
    status, headers, body = request(port, '/api/control-session')
    assert status == 200
    assert_safe_headers(headers, 'application/json')
    return {'Origin': f'http://127.0.0.1:{port}', 'Content-Type': 'application/json',
            'X-Control-Token': json.loads(body)['csrf_token']}


def test_stop_is_durable_idempotent_and_strategy_scoped(control_project):
    root, db = control_project
    with running_server(root, db) as port:
        headers = control_headers(port)
        body = json.dumps({'action': 'stop', 'strategy': 'orb'})
        first = request(port, '/api/control', 'POST', body=body, headers=headers)
        assert first[0] == 200
        receipt = json.loads(first[2])['strategies']['orb']
        assert receipt['runtime'] == 'RISK_HALTED'
        assert receipt['broker_flat_verified'] is False
        assert receipt['working_orders'] == 0
        assert receipt['open_positions'] == 0
        again = request(port, '/api/control', 'POST', body=body, headers=headers)
        assert again[0] == first[0] and again[2] == first[2]
    with running_server(root, db) as port:
        data = json.loads(request(port, '/api/status')[2])
        a, b = data['portfolios']
        assert a['controls']['manual_locked'] is True
        assert a['controls']['stop_enabled'] is False
        assert a['runtime'] == 'RISK_HALTED'
        assert b['runtime'] == 'SHADOW' and b['controls']['stop_enabled'] is True
        assert all(p['nav'] == p['initial_nav'] == 50000 and p['order_count'] == 0 for p in (a, b))
        assert data['chain_verified']
        assert len([e for e in data['audit'] if e['kind'] == 'MANUAL_CONTROL']) == 1
        assert all('csrf_token' not in request(port, path)[2] for path in ('/api/status', '/export/status.json', '/export/audit.csv'))


def test_start_cannot_override_release_boundary(control_project):
    root, db = control_project
    with running_server(root, db) as port:
        headers = control_headers(port)
        before = json.loads(request(port, '/api/status')[2])['event_count']
        for strategy in ('orb', 'noise_area'):
            status, _, body = request(port, '/api/control', 'POST', headers=headers,
                                      body=json.dumps({'action': 'start', 'strategy': strategy}))
            assert status == 409
            assert json.loads(body)['execution_enabled'] is False
            assert json.loads(body)['blockers']
        after = json.loads(request(port, '/api/status')[2])
        assert after['event_count'] == before
        assert all(p['runtime'] == 'SHADOW' and not p['controls']['start_enabled'] for p in after['portfolios'])


@pytest.mark.parametrize('changes', [
    {'Origin': 'https://attacker.example'}, {'Origin': 'null'}, {'Origin': None},
    {'Origin': 'http://127.0.0.1:1'}, {'X-Control-Token': ''}, {'X-Control-Token': 'wrong'},
    {'X-Control-Token': '\u00ff'}, {'Sec-Fetch-Site': 'cross-site'}, {'Host': 'attacker.example'},
])
def test_cross_origin_and_missing_tokens_cannot_stop(control_project, changes):
    root, db = control_project
    with running_server(root, db) as port:
        headers = control_headers(port) | changes
        headers = {key: value for key, value in headers.items() if value is not None}
        status, _, _ = request(port, '/api/control', 'POST', headers=headers,
                               body=json.dumps({'action': 'stop', 'strategy': 'orb'}))
        assert status == 403
        assert json.loads(request(port, '/api/status')[2])['portfolios'][0]['runtime'] == 'SHADOW'


@pytest.mark.parametrize('body,changes,expected', [
    ('{bad', {}, 400), ('[]', {}, 400), ('null', {}, 400),
    ('{"action":"stop","strategy":"all"}', {}, 400),
    ('{"action":"kill","strategy":"orb"}', {}, 400),
    ('{"action":"stop","strategy":"orb","command":"shell"}', {}, 400),
    ('{"action":"stop","strategy":"orb"}', {'Content-Type': 'text/plain'}, 400),
    ('{"action":"stop","strategy":"orb"}', {'Transfer-Encoding': 'chunked'}, 400),
    ('x' * 1025, {}, 413), ('', {}, 413),
])
def test_control_body_is_narrow_and_bounded(control_project, body, changes, expected):
    root, db = control_project
    with running_server(root, db) as port:
        headers = control_headers(port) | changes
        assert request(port, '/api/control', 'POST', headers=headers, body=body)[0] == expected
        assert json.loads(request(port, '/api/status')[2])['portfolios'][0]['runtime'] == 'SHADOW'


def test_stop_does_not_initialize_missing_ledger(tmp_path):
    missing = tmp_path / 'missing.sqlite3'
    with running_server(tmp_path, missing) as port:
        headers = control_headers(port)
        assert request(port, '/api/control', 'POST', headers=headers,
                       body='{"action":"stop","strategy":"orb"}')[0] == 503
        assert not missing.exists()


def test_stop_cannot_clear_terminal_state(control_project):
    from dual_strategy.cli import control
    root, db = control_project
    control(root, db, 'kill', 'orb')
    with running_server(root, db) as port:
        headers = control_headers(port)
        response = request(port, '/api/control', 'POST', headers=headers,
                           body='{"action":"stop","strategy":"orb"}')
        assert response[0] == 200
        assert json.loads(response[2])['strategies']['orb']['runtime'] == 'TERMINATED'
        data = json.loads(request(port, '/api/status')[2])
        assert len([e for e in data['audit'] if e['kind'] == 'MANUAL_CONTROL']) == 1
        assert data['portfolios'][0]['controls']['start_blockers'][-1] == 'Terminal stop cannot be cleared.'


class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


def test_accessible_local_csp_markup():
    parser = AssetParser()
    parser.feed((ASSETS / 'index.html').read_text(encoding='utf-8'))
    scripts = [attrs for tag, attrs in parser.tags if tag == 'script']
    assert len(scripts) == 1 and scripts[0]['src'] == '/app.js'
    assert [attrs['href'] for tag, attrs in parser.tags if tag == 'link' and attrs.get('rel') == 'stylesheet'] == ['/style.css']
    assert not any(tag == 'style' for tag, _ in parser.tags)
    assert not any(key == 'style' or key.startswith('on') for _, attrs in parser.tags for key in attrs)
    labels = {attrs['for'] for tag, attrs in parser.tags if tag == 'label'}
    assert {'strategy-filter', 'event-search'} <= labels
    assert any(attrs.get('role') == 'alert' for _, attrs in parser.tags)
    assert {'/export/status.json', '/export/audit.csv', '/export/equity.csv'} <= {attrs.get('href') for tag, attrs in parser.tags if tag == 'a'}
    source = (ASSETS / 'app.js').read_text(encoding='utf-8')
    for unsafe in ('innerHTML', 'outerHTML', 'insertAdjacentHTML', 'document.write(', 'eval('):
        assert unsafe not in source
    css = (ASSETS / 'style.css').read_text(encoding='utf-8')
    assert 'prefers-reduced-motion' in css and ':focus-visible' in css
    assert '#live-data.is-stale' in css and 'grayscale(1)' in css


# A small strict DOM fake: any accidental HTML insertion fails rather than being
# silently accepted. Node is only a test runner; the shipped UI has no dependencies.
DOM_HARNESS = r'''
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const ids = new Map();
class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.attributes = {}; this.listeners = {}; this.className = ''; this.value = ''; this.hidden = false; this.open = false; this._text = ''; }
  set innerHTML(value) { throw new Error('Unsafe HTML insertion'); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text + this.children.map(c => c.textContent).join(''); }
  get childElementCount() { return this.children.length; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this._text = ''; this.children = children; }
  setAttribute(key, value) { this.attributes[key] = String(value); }
  addEventListener(name, fn) { this.listeners[name] = fn; }
  get classList() {
    return { toggle: (name, on) => {
      const values = new Set(this.className.split(' ').filter(Boolean));
      if (on) values.add(name); else values.delete(name);
      this.className = [...values].join(' ');
    }, contains: name => this.className.split(' ').includes(name),
       add: name => this.classList.toggle(name, true), remove: name => this.classList.toggle(name, false) };
  }
}
for (const id of input.ids) ids.set(id, new Element('div'));
const get = id => { assert.ok(ids.has(id), `Missing HTML id: ${id}`); return ids.get(id); };
get('strategy-filter').value = 'all';
let clock = Date.parse(input.status.generated_at);
class Clock extends Date { static now() { return clock; } }
const queue = [input.initial_failure ? { status: 503 } : { data: input.status }];
const requests = [];
const intervals = [];
const timeouts = new Map();
let timerId = 0;
const context = {
  document: { getElementById: get, createElement: tag => new Element(tag), createElementNS: (_, tag) => new Element(tag) },
  Date: Clock, AbortController, console,
  setInterval: (fn, ms) => { intervals.push({ fn, ms }); return intervals.length; },
  setTimeout: (fn, ms) => { const id = ++timerId; timeouts.set(id, { fn, ms }); return id; },
  clearTimeout: id => timeouts.delete(id),
  fetch: async (url, options) => {
    requests.push({ url, options });
    const item = queue.shift();
    assert.ok(item, 'Unexpected extra request');
    if (item.error) throw item.error;
    if (item.hang) return new Promise((resolve, reject) => options.signal.addEventListener('abort', () => { const e = new Error('aborted'); e.name = 'AbortError'; reject(e); }));
    return { ok: !item.status || item.status === 200, status: item.status || 200, json: async () => { if (item.badJSON) throw new SyntaxError('Invalid JSON'); return item.data; } };
  },
};
function nodes(root, tag) { return [...(root.tagName === tag ? [root] : []), ...root.children.flatMap(child => nodes(child, tag))]; }
function text(id) { return get(id).textContent; }
function fresh() { const data = structuredClone(input.status); data.generated_at = new Date(clock).toISOString(); return data; }
async function settle() { await new Promise(resolve => setImmediate(resolve)); }
async function load(item) { queue.push(item); await get('refresh-button').listeners.click(); }
function stale() { return get('live-data').classList.contains('is-stale'); }
function metricValue(label) { const card = get('portfolios').children[0]; const box = nodes(card, 'div').find(n => n.children[0]?.tagName === 'dt' && n.children[0].textContent === label); assert.ok(box, label); return box.children[1].textContent; }
(async () => {
  vm.runInNewContext(fs.readFileSync(input.app, 'utf8'), context);
  await settle();
  if (input.initial_failure) {
    assert.match(text('data-alert'), /No ledger data has been received/);
    assert.match(text('portfolios'), /Ledger unavailable/);
    assert.ok(!text('portfolios').includes('$50,000'));
    assert.equal(stale(), true);
    assert.equal(get('refresh-button').disabled, false);
    assert.equal(nodes(get('equity-chart'), 'polyline').length, 0);
    await load({ data: fresh() });
    assert.equal(get('portfolios').childElementCount, 2);
    assert.equal(stale(), false);
    assert.equal(get('data-alert').hidden, true);
    console.log('Dashboard DOM behaviors passed');
    return;
  }
  assert.equal(get('portfolios').childElementCount, 2);
  assert.match(text('portfolios'), /No completed trades/);
  assert.match(text('portfolios'), /No fills recorded/);
  assert.match(text('portfolios'), /not connected/);
  assert.match(text('portfolios'), /read only roles deployed/);
  assert.match(text('portfolios'), /\$50,000\.00/);
  assert.match(metricValue('Sharpe'), /—Insufficient sample/);
  assert.match(metricValue('Sortino'), /—Insufficient sample/);
  assert.equal(metricValue('Completed trades'), '0');
  assert.match(metricValue('Orders / fill ratio'), /^0 \/ —/);
  assert.equal(metricValue('Daily loss remaining').startsWith('$625.00'), true);
  assert.equal(nodes(get('equity-chart'), 'polyline').length, 0, 'Do not invent a line from initial capital');
  assert.equal(nodes(get('equity-chart'), 'circle').length, 2);
  assert.equal(nodes(get('drawdown-chart'), 'polyline').length, 0);
  assert.match(text('chart-note'), /No benchmark supplied/);
  assert.match(text('research-json'), /999999/);
  assert.ok(!text('portfolios').includes('999999'));
  assert.match(text('capabilities-summary'), /\$1,000,000\.00/);
  assert.match(text('capabilities-summary'), /unchanged/);
  assert.match(text('capabilities-summary'), /SHARED PRACTICE ACCOUNT/);
  assert.equal(stale(), false);
  assert.equal(intervals.find(t => t.ms === 5000).ms, 5000);
  assert.equal(timeouts.size, 0);
  for (const r of requests) { assert.equal(r.url, '/api/status'); assert.equal(r.options.cache, 'no-store'); assert.ok(!r.options.method || r.options.method === 'GET'); }

  // Audit filters search payloads, preserve safe text, and keep expansions on refresh.
  get('event-search').value = '<img';
  get('event-search').listeners.input();
  assert.equal(get('audit-body').childElementCount, 1);
  assert.match(text('audit-body'), /<img src=x onerror=alert\(1\)>/);
  assert.equal(nodes(get('audit-body'), 'img').length, 0);
  let details = nodes(get('audit-body'), 'details')[0];
  details.open = true; details.listeners.toggle();
  await load({ data: fresh() });
  assert.equal(nodes(get('audit-body'), 'details')[0].open, true);
  get('strategy-filter').value = 'noise_area';
  get('strategy-filter').listeners.change();
  assert.match(text('audit-body'), /No events match/);
  get('event-search').value = ''; get('event-search').listeners.input();
  assert.equal(get('audit-body').childElementCount, 1);
  assert.match(text('audit-body'), /B · SPY Noise-Area/);
  get('strategy-filter').value = 'all'; get('strategy-filter').listeners.change();

  // Network failures and malformed payloads retain the last good DOM, visibly stale.
  const card = get('portfolios').children[0];
  const navBefore = text('portfolios');
  await load({ status: 503 });
  assert.equal(get('portfolios').children[0], card);
  assert.equal(text('portfolios'), navBefore);
  assert.equal(stale(), true);
  assert.match(text('data-alert'), /HTTP 503/);
  assert.equal(get('data-alert').hidden, false);
  await load({ badJSON: true });
  assert.equal(get('portfolios').children[0], card);
  await load({ data: { generated_at: 'invalid' } });
  assert.equal(get('portfolios').children[0], card);
  const incomplete = fresh(); incomplete.portfolios.pop();
  await load({ data: incomplete });
  assert.equal(get('portfolios').children[0], card);
  await load({ data: fresh() });
  assert.equal(stale(), false);
  assert.equal(get('data-alert').hidden, true);
  clock += 16000;
  intervals.find(t => t.ms === 1000).fn();
  assert.equal(stale(), true);
  assert.match(text('data-alert'), /Stale snapshot/);
  queue.push({ data: fresh() });
  await intervals.find(t => t.ms === 5000).fn();
  assert.equal(stale(), false);
  const old = fresh(); old.generated_at = new Date(clock - 1000).toISOString();
  await load({ data: old });
  assert.match(text('data-alert'), /Out-of-order/);
  await load({ data: fresh() });

  // A hung request is aborted, never overlaps, and leaves values intact.
  queue.push({ hang: true });
  const pending = get('refresh-button').listeners.click();
  await settle();
  const before = requests.length;
  await intervals.find(t => t.ms === 5000).fn();
  assert.equal(requests.length, before);
  assert.equal(get('refresh-button').disabled, true);
  [...timeouts.values()].find(t => t.ms === 8000).fn();
  await pending;
  assert.match(text('data-alert'), /timed out/);
  assert.equal(stale(), true);
  assert.equal(get('refresh-button').disabled, false);
  await load({ data: fresh() });

  // Chart values use each actual initial NAV, not the first sample or research.
  const history = fresh();
  history.portfolios[0].initial_nav = 50000;
  history.portfolios[0].equity = [{ at: '2026-11-16T17:00:00Z', nav: 50000 }, { at: '2026-11-17T17:00:00Z', nav: 51000 }];
  history.portfolios[0].drawdown_curve = [{ at: '2026-11-16T17:00:00Z', drawdown_pct: 0 }, { at: '2026-11-17T17:00:00Z', drawdown_pct: -2 }];
  history.portfolios[1].initial_nav = 100000;
  history.portfolios[1].equity = [{ at: '2026-11-16T17:00:00Z', nav: 100000 }, { at: '2026-11-17T17:00:00Z', nav: 102000 }];
  history.portfolios[1].drawdown_curve = structuredClone(history.portfolios[0].drawdown_curve);
  await load({ data: history });
  let lines = nodes(get('equity-chart'), 'polyline');
  assert.equal(lines.length, 2);
  assert.equal(lines[0].attributes.points, lines[1].attributes.points);
  assert.match(text('equity-chart'), /102.00 index/);
  assert.match(text('drawdown-chart'), /−?\-?2.00%/);
  assert.equal(nodes(get('drawdown-chart'), 'polyline').length, 2);
  history.benchmark = { label: '<script>benchmark</script>', initial_nav: 10, equity: [{ at: '2026-11-16T17:00:00Z', nav: 10 }, { at: '2026-11-17T17:00:00Z', nav: 11 }], drawdown_curve: [] };
  await load({ data: history });
  assert.equal(nodes(get('equity-chart'), 'polyline').length, 3);
  assert.equal(nodes(get('drawdown-chart'), 'polyline').length, 2, 'Never manufacture benchmark drawdown');
  assert.equal(nodes(get('chart-legend'), 'script').length, 0);
  assert.match(text('chart-legend'), /<script>benchmark<\/script>/);
  const gap = fresh();
  gap.portfolios[0].equity = [history.portfolios[0].equity[0], { at: 'bad', nav: 100 }, history.portfolios[0].equity[1]];
  await load({ data: gap });
  assert.equal(nodes(get('equity-chart'), 'polyline').length, 0, 'An invalid point breaks continuity');

  const empty = fresh(); empty.research = null; empty.capabilities = {}; empty.audit = []; empty.event_count = 0;
  empty.portfolios.forEach(p => { p.equity = []; p.drawdown_curve = []; });
  await load({ data: empty });
  assert.match(text('equity-chart'), /No observed equity/);
  assert.match(text('drawdown-chart'), /No observed drawdown/);
  assert.match(text('audit-body'), /No ledger events/);
  assert.match(text('research-summary'), /No research report/);
  assert.equal(get('research-details').hidden, true);
  assert.equal(text('research-json'), '');
  assert.match(text('capabilities-summary'), /No shared-practice mapping/);
  const broken = fresh(); broken.chain_verified = false;
  await load({ data: broken });
  assert.match(text('data-alert'), /Audit-chain verification failed/);
  const unexpected = fresh(); unexpected.execution_enabled = true;
  await load({ data: unexpected });
  assert.match(text('data-alert'), /Unexpected execution flag/);
  console.log('Dashboard DOM behaviors passed');
})().catch(error => { console.error(error); process.exitCode = 1; });
'''


@pytest.mark.parametrize('initial_failure', [False, True])
def test_dashboard_dom_refresh_charts_filters_and_failures(project, initial_failure):
    node = shutil.which('node')
    if node is None:
        pytest.skip('Node is needed for the dependency-free DOM test')
    root, db = project
    parser = AssetParser()
    parser.feed((ASSETS / 'index.html').read_text(encoding='utf-8'))
    payload = {
        'app': str(ASSETS / 'app.js'),
        'initial_failure': initial_failure,
        'ids': [attrs['id'] for _, attrs in parser.tags if 'id' in attrs],
        'status': service.report_status(db, root, NOW),
    }
    result = subprocess.run([node, '-e', DOM_HARNESS], input=json.dumps(payload), text=True,
                            encoding='utf-8', capture_output=True, timeout=20)
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'Dashboard DOM behaviors passed' in result.stdout


def test_backtest_scoreboard_served_read_only_or_404(project, endpoint):
    root, _ = project
    status, _, body = request(endpoint, '/api/backtest')
    assert status == 404 and 'research.run' in json.loads(body)['error']
    board = root / 'reports' / 'backtest_v3'
    board.mkdir(parents=True)
    payload = {'label': 'SIMULATED', 'variants': [], 'equity_oos': {'dates': [], 'series': {}}}
    (board / 'scoreboard.json').write_text(json.dumps(payload), encoding='utf-8')
    status, headers, body = request(endpoint, '/api/backtest')
    assert status == 200 and json.loads(body) == payload
    assert_safe_headers(headers, 'application/json')
    assert request(endpoint, '/api/backtest', method='POST')[0] == 405


COMPETITION_DOM = DOM_HARNESS.split('(async () => {')[0] + r'''
(async () => {
  vm.runInNewContext(fs.readFileSync(input.app, 'utf8'), context);
  await settle();
  assert.equal(stale(), false, text('data-alert'));
  assert.match(text('runner-summary'), /Waiting for market open/);
  assert.match(text('nav-summary'), /Awaiting account observation/);
  assert.equal(text('market-countdown'), '01:30:00');
  assert.match(text('sleeves'), /XLV/);
  assert.match(text('sleeves'), /XLP/);
  assert.match(text('vote-cards'), /SPY.*QQQ/);
  assert.match(text('vote-note'), /Completed bar/);
  assert.match(text('vote-cards'), /Short signal/);
  assert.match(text('vote-rule-rows'), /Donchian.*Sell short/);
  assert.equal(get('rule-activity-date').value, '2026-11-20');
  assert.equal(text('latest-trade'), 'No trades recorded yet.');
  assert.equal(text('trade-count'), '0 trades · 0 tonight');
  assert.match(text('rule-activity-date'), /^Tonight · Fri 20 NovAll nights · totals$/);
  assert.match(text('rule-activity-body'), /^Donchian0——Keltner0——.*NR70——Noise-area \(SPY only\)0—n\/aTrade signal \(2\+ rules agree\)0——$/);
  assert.match(text('rule-activity-summary'), /Tonight: no vote records yet/);
  assert.equal(nodes(get('equity-chart'), 'svg').length, 0);

  const live = fresh();
  live.runtime.market_phase = 'open';
  live.runtime.mark_status = 'stale'; live.runtime.mark_age_seconds = 300;
  Object.assign(live.live, {nav_estimate:100000, high_water:100000, day:live.outbox_session, day_start_nav:100000});
  live.account_snapshot = {at:live.generated_at,cash:96000,positions:{'US.XLV':11,'US.SPY':-2},quotes:{'US.XLV':177}};
  live.live.sleeves.h_etf = {'US.XLV':11};
  live.b3_decision = {at:live.generated_at,target:1,reason:'long',metrics:{close:502,upper:501,vwap:500},plan_reason:'entry'};
  live.orders = [{created_at:live.generated_at,intent_id:'one',audit_id:'a',sleeve:'h_etf',symbol:'US.XLV',side:'BUY',qty:11,limit_price:177.5,reference_price:177.4,reason:'h_entry',status:'FILLED',filled:11,avg_price:177.123456789},
    {created_at:live.generated_at,intent_id:'two',audit_id:'b',sleeve:'b3',symbol:'US.SPY',side:'BUY',qty:50,status:'UNCONFIRMED',filled:null,avg_price:null}];
  live.equity = [{at:'2026-11-20T14:30:00Z',nav:100000,drawdown_pct:0},{at:'2026-11-20T14:31:00Z',nav:100200,drawdown_pct:-.1},{at:'2026-11-20T14:40:00Z',nav:100300,drawdown_pct:0}];
  live.outbox = [{event:'runner_error',step:'risk',logged_at:live.generated_at,error:'<img src=x onerror=alert(1)>'}];
  live.step_errors = {risk:2};
  live.performance={asof:live.generated_at,account_pnl:19.19,unallocated_account_change:-1.98,sleeves:{
    b3:{status:'available',gross_pnl:0,realized_gross:0,unrealized_gross:0,fill_count:0,fees:0,net_pnl:0,initial_capital:80000,capital:80000,limits:{allocation_budget:80000,target_before_cap:80000,per_etf_budget:null,aggregate_limit:null}},
    h_etf:{status:'available',gross_pnl:21.17,realized_gross:0,unrealized_gross:21.17,fill_count:2,fees:null,net_pnl:null,initial_capital:20000,capital:20021.17,limits:{allocation_budget:20021.17,target_before_cap:null,per_etf_budget:2002.117,aggregate_limit:6006.351}}}};
  live.live.take_profit_counts = {two_vote:{'US.QQQ':1}};
  live.performance.exits = {status:'available', totals:{realized_gross:12, closed_trade_gross:12,
      exit_orders:2, manual_exits:1, automatic_exits:1, closed_trade_count:1, expectancy_dollars:12},
    sleeves:{two_vote:{realized_gross:12}}, reviews:{'2026-11-19':'review'},
    fills:[{session:'2026-11-19', sleeve:'two_vote', symbol:'US.QQQ', side:'SELL', source:'manual',
      shares:3, avg_price:123.45, realized_gross:9, status:'FILLED', audit_id:'audit', intent_id:'exit'}]};
  live.performance.trades = [
    {session:'2026-11-19', sleeve:'two_vote', symbol:'US.QQQ', side:'BUY', action:'buy', shares:3, avg_price:120.45, realized_gross:null,
     reason:'two_vote_long', source:'automatic', status:'FILLED', ordered_at:'2026-11-19T10:55:17-05:00', audit_id:'a0',
     intent_id:'2026-11-19-two_vote-e17-QQQ-BUY', rules:['Donchian','RSI(2)'], verified:true},
    {session:'2026-11-19', sleeve:'two_vote', symbol:'US.QQQ', side:'SELL', action:'sell', shares:3, avg_price:123.45, realized_gross:9,
     reason:'user_manual_sell', source:'manual', status:'FILLED', ordered_at:'2026-11-19T20:43:35+00:00', audit_id:'audit', intent_id:'exit', verified:true},
    {session:'2026-11-20', sleeve:'two_vote', symbol:'US.SPY', side:'SELL', action:'short', shares:2, avg_price:500.5, realized_gross:null,
     reason:'two_vote_short', source:'automatic', status:'FILLED', ordered_at:'2026-11-20T10:30:18-05:00', audit_id:'a2',
     intent_id:'2026-11-20-two_vote-e12-SPY-SELL', rules:['Donchian','Keltner'], verified:true}];
  await load({data:live});
  assert.equal(text('trade-count'), '3 trades · 1 tonight');
  assert.match(text('positions-body'), /No open positions\. Everything is closed\./);
  assert.equal(text('latest-trade'), 'Latest trade: Sold short 2 SPY at $500.50 · Fri 20 Nov 23:30 SGT · Two-vote · 2+ rules voted Sell: Donchian, Keltner.');
  assert.ok(get('latest-trade').classList.contains('is-today'));
  assert.match(text('exit-metrics'), /Account P&L\$19\.19.*Realized P&L · gross\$12\.00.*Open positionsNoneEverything is closed.*Trades31 tonight · 2 entries · 1 close.*Profit-target activations1.*Expectancy per closed trade\$12\.00/);
  assert.match(text('exit-body'), /^Fri 20 Nov 23:30Two-vote · SPYSold short2\+ rules voted Sell: Donchian, Keltner2\$500\.50EntryEvidence/);
  assert.match(text('exit-body'), /Fri 20 Nov 04:43Two-vote · QQQSold · manualYou sold it manually3\$123\.45\$9\.00Evidence.*"session_review": "review"/s);
  assert.match(text('exit-body'), /Thu 19 Nov 23:55Two-vote · QQQBought2\+ rules voted Buy: Donchian, RSI\(2\)3\$120\.45Entry/);
  assert.equal(get('exit-body').children[0].className, 'today-row');
  assert.equal(get('exit-body').children[1].className, '');
  assert.match(text('expectancy-formula'), /win rate × average win.*\$12.00 per trade.*when the order was placed/);
  const withOpen = structuredClone(live);
  withOpen.performance.sleeves.two_vote = {status:'available', positions:{'US.SPY':{qty:-2, cost_basis:-1001, mark_price:501, unrealized_gross:-1}}};
  withOpen.open_positions = [{sleeve:'two_vote', symbol:'US.SPY', qty:-2, side:'short', entry_price:500.5, cost:1001,
    opened_at:'2026-11-20T10:30:18-05:00', mark_price:501, value:1002, unrealized_gross:-1, take_profit_usd:50, take_profit_price:475.5}];
  withOpen.runtime.session_close = '2026-11-20T16:00:00-05:00';
  await load({data:withOpen});
  assert.match(text('latest-trade'), /Still open: -\$1\.00 unrealized\.$/);
  assert.equal(text('positions-body'), 'Two-vote · SPY2 short$500.50Fri 20 Nov 23:30$1,001.00$501.00-$1.00Profit target: ≤ $475.50 (+$50.00) · or 2+ Buy votes · or auto-close 04:55 SGT');
  assert.equal(get('positions-body').children[0].children[6].className, 'negative');
  assert.match(text('exit-metrics'), /Open positionsSPY 2 shortUnrealized -\$1\.00/);
  const noTrades = structuredClone(live); delete noTrades.performance.trades;
  await load({data:noTrades});
  assert.equal(text('trade-count'), 'Unavailable');
  assert.match(text('latest-trade'), /unavailable/);
  assert.match(text('exit-body'), /Trade list unavailable/);
  await load({data:live});
  live.vote_activity = {status:'available', today:'2026-11-20',
    sessions:{'2026-11-19':{first_bar:'2026-11-19T10:45:00-05:00',last_bar:'2026-11-19T15:55:00-05:00',bars:62},
              '2026-11-20':{first_bar:'2026-11-20T10:00:00-05:00',last_bar:'2026-11-20T10:10:00-05:00',bars:3}},
    rules:[{rule:'Donchian',today:1,total:2,fires:[
              {session:'2026-11-19',symbol:'US.SPY',side:'BUY',bar_end:'2026-11-19T10:45:00-05:00',slot:15,first_observed:true},
              {session:'2026-11-20',symbol:'US.QQQ',side:'SELL',bar_end:'2026-11-20T10:05:00-05:00',slot:7,first_observed:false}]},
           {rule:'Keltner',today:0,total:0,fires:[]},{rule:'Noise-area',today:0,total:0,fires:[]}],
    signals:[{session:'2026-11-19',symbol:'US.SPY',side:'BUY',bar_end:'2026-11-19T11:45:00-05:00',slot:27,first_observed:false}]};
  await load({data:live});
  const picker = get('rule-activity-date');
  assert.equal(picker.value, '2026-11-20');
  assert.equal(text('rule-activity-date'), 'Tonight · Fri 20 NovThu 19 Nov nightAll nights · totals');
  assert.match(text('rule-activity-body'), /^Donchian1—23:05 SellKeltner0——Noise-area \(SPY only\)0—n\/aTrade signal \(2\+ rules agree\)0——$/);
  assert.equal(text('rule-activity-summary'), 'Tonight: 1 rule fire · 0 trade signals. Runner recorded 3 bars, 23:00–23:10 SGT.');
  assert.equal(text('rule-activity-spy-label'), 'SPY · time fired (SGT)');
  picker.value = '2026-11-19'; picker.listeners.change();
  assert.match(text('rule-activity-body'), /^Donchian123:45 Buy · already on—.*Trade signal \(2\+ rules agree\)100:45 Buy—$/);
  assert.match(text('rule-activity-summary'), /^Thu 19 Nov night: 1 rule fire · 1 trade signal\. Runner recorded 62 bars, 23:45–04:55 SGT\. Records started late/);
  const chips = nodes(get('rule-activity-body'), 'span');
  assert.match(chips[0].attributes.title, /already on when the runner's records began at 23:45 SGT/);
  assert.match(chips[1].attributes.title, /switched on when the 5-minute bar closed at 00:45 SGT/);
  assert.equal(chips.filter(n => n.className.includes('negative')).length, 0);
  await load({data:live});
  assert.equal(get('rule-activity-date').value, '2026-11-19', 'Selected night survives the 5-second refresh');
  assert.match(text('rule-activity-body'), /23:45 Buy · already on/);
  picker.value = 'all'; picker.listeners.change();
  assert.match(text('rule-activity-body'), /^Donchian211Keltner000Noise-area \(SPY only\)00n\/aTrade signal \(2\+ rules agree\)110$/);
  assert.equal(text('rule-activity-count-label'), 'Fires · all nights');
  assert.equal(text('rule-activity-summary'), 'All 2 recorded nights: 2 rule fires · 1 trade signal. Pick a night to see the times.');
  picker.value = '2026-11-20'; picker.listeners.change();
  const noActivity = structuredClone(live); delete noActivity.vote_activity;
  await load({data:noActivity});
  assert.match(text('rule-activity-summary'), /unavailable/);
  assert.match(text('rule-activity-body'), /No rule activity available/);
  await load({data:live});
  const pnl=card=>nodes(card,'div').find(n=>n.className.split(' ').includes('nav-value')).textContent;
  assert.equal(pnl(get('sleeves').children[0]),'$0.00');
  assert.equal(pnl(get('sleeves').children[1]),'$21.17');
  assert.match(text('sleeves'),/Strategy P&L · before fees/);
  assert.match(text('sleeves'),/Fees not attributed/);
  assert.match(text('attribution-note'),/not split by the allocation weights/);
  live.live.nav_estimate=110000;
  live.performance.sleeves.b3={...live.performance.sleeves.b3,initial_capital:80000,capital:80000,limits:{allocation_budget:80000,target_before_cap:80000,per_etf_budget:null,aggregate_limit:null}};
  live.performance.sleeves.h_etf={...live.performance.sleeves.h_etf,initial_capital:20000,capital:20021.17,limits:{allocation_budget:20021.17,target_before_cap:null,per_etf_budget:2002.117,aggregate_limit:6006.351}};
  await load({data:live});
  const cardText=card=>card.textContent;
  assert.ok(cardText(get('sleeves').children[0]).includes('$80,000.00'));
  assert.ok(!cardText(get('sleeves').children[0]).includes('$88,000.00'));
  for (const value of ['$20,021.17','$2,002.12','$6,006.35']) assert.ok(cardText(get('sleeves').children[1]).includes(value),value);
  assert.match(text('sleeves'),/initial capital/i);
  live.live.nav_estimate=100000;
  live.performance.sleeves.h_etf.capital=20000;
  live.performance.sleeves.h_etf.limits={allocation_budget:20000,target_before_cap:null,per_etf_budget:2000,aggregate_limit:6000};
  await load({data:live});
  assert.match(text('runner-summary'), /Running/);
  assert.match(text('mark-summary'), /Stale/);
  assert.match(text('health-alert'), /risk × 2/);
  for (const value of ['$80,000.00', '$20,000.00', '$2,000.00', '$6,000.00', '$1,947.00', 'LONG signal', '$502.00']) assert.ok(text('sleeves').includes(value), value);
  assert.match(text('orders-body'), /177.1235/);
  assert.match(text('orders-body'), /177.123456789/);
  assert.match(text('orders-body'), /UNCONFIRMED/);
  assert.ok(!text('orders-body').includes('Sent'));
  assert.equal(nodes(get('audit-body'), 'img').length, 0);
  assert.match(text('audit-body'), /<img/);
  const path = nodes(get('equity-chart'), 'path')[0].attributes.d;
  assert.equal((path.match(/M/g)||[]).length,2);
  assert.equal((path.match(/L/g)||[]).length,1);
  get('strategy-filter').value='b3';get('strategy-filter').listeners.change();
  assert.match(text('orders-body'), /SPY/);assert.ok(!text('orders-body').includes('XLV'));
  get('strategy-filter').value='all';get('strategy-filter').listeners.change();
  get('event-search').value='no-match';get('event-search').listeners.input();
  assert.match(text('orders-body'), /No matching/);
  get('event-search').value='';get('event-search').listeners.input();
  let details=nodes(get('orders-body'),'details')[0];details.open=true;details.listeners.toggle();
  let eventDetails=nodes(get('audit-body'),'details')[0];eventDetails.open=true;eventDetails.listeners.toggle?.();
  await load({data:live});
  assert.equal(nodes(get('orders-body'),'details')[0].open,true);
  assert.equal(nodes(get('audit-body'),'details')[0].open,true);
  live.live.halted={kind:'order_error'};live.live.order_errors_today=3;
  await load({data:live});
  assert.match(text('risk-summary'), /Order-error halt/);assert.match(text('health-alert'), /3 order errors/);
  for (const [status,label] of [['stopped',/Stopped/],['unknown',/unverified/],['multiple',/Multiple/]]) {
    live.runtime.process.status=status;await load({data:live});assert.match(text('runner-summary'),label);
  }
  assert.match(text('sleeves'), /initial capital \+ own gross P&L/);
  const unknownCapital=structuredClone(live);
  unknownCapital.performance.sleeves.h_etf={...unknownCapital.performance.sleeves.h_etf,status:'incomplete',gross_pnl:null,capital:null,limits:{allocation_budget:null,target_before_cap:null,per_etf_budget:null,aggregate_limit:null}};
  await load({data:unknownCapital});
  assert.match(text('sleeves'),/Capital unverified; new entries blocked/);
  assert.equal(nodes(get('sleeves').children[1],'progress').length,0);
  const unknownLimits=nodes(get('sleeves').children[1],'dl').find(n=>n.className.includes('capital-metrics'));
  assert.equal(nodes(unknownLimits,'dd').filter(n=>n.textContent.startsWith('—')).length,3);
  assert.ok(get('sleeves').children[0].textContent.includes('$80,000.00'));
  await load({data:live});
  live.access={status:'sign_in_required',at:live.generated_at};
  live.startup={status:'blocked',session:'2026-11-23',at:live.generated_at,reason:'read_only_preflight_failed_twice'};
  await load({data:live});
  assert.equal(get('attention-alert').hidden,false);
  assert.match(text('attention-alert'), /Sign-in required/);
  assert.match(text('attention-alert'), /moomoo auth login/);
  assert.match(text('attention-alert'), /Startup blocked/);
  assert.match(text('attention-alert'), /Do not restart/);
  assert.match(text('health-alert'), /3 order errors/);
  live.access={status:'check_required',at:live.generated_at};
  live.startup={status:'unverified',session:null,at:null};
  await load({data:live});
  assert.doesNotMatch(text('attention-alert'), /Sign-in required/);
  assert.match(text('attention-alert'), /Check sign-in and connection/);
  assert.match(text('attention-alert'), /Startup status unavailable/);
  live.access={status:'recent_success',at:live.generated_at};
  live.startup={status:'checking',session:'2026-11-23',at:live.generated_at};
  await load({data:live});
  assert.equal(get('attention-alert').hidden,true);
  assert.match(text('access-summary'), /Recent successful account read/);
  assert.match(text('startup-summary'), /Preflight in progress/);
  live.access={status:'unverified',at:null};
  live.startup={status:'not_recorded',session:null,at:null};
  await load({data:live});
  assert.match(text('access-summary'), /Not independently verified/);
  assert.match(text('startup-summary'), /No startup attempt recorded/);
  assert.equal(get('attention-alert').hidden,true);
  live.access={status:'sign_in_required',at:live.generated_at};
  live.startup={status:'blocked',session:'<img src=x onerror=alert(1)>',at:live.generated_at,reason:'<script>'};
  await load({data:live});
  assert.equal(nodes(get('attention-alert'),'img').length,0);
  assert.equal(nodes(get('attention-alert'),'script').length,0);
  const card=get('sleeves').children[0];
  for (const failed of [{status:503},{badJSON:true},{data:{generated_at:'bad'}}]) {
    await load(failed);assert.equal(stale(),true);assert.equal(get('sleeves').children[0],card);
  }
  await load({data:fresh()});assert.equal(stale(),false);
  queue.push({hang:true});const pending=get('refresh-button').listeners.click();await settle();
  const count=requests.length;await intervals.find(t=>t.ms===5000).fn();assert.equal(requests.length,count);
  [...timeouts.values()].find(t=>t.ms===6000).fn();await pending;
  assert.match(text('data-alert'),/timed out/);
  await load({data:fresh()});
  clock+=16000;intervals.find(t=>t.ms===1000).fn();assert.equal(stale(),true);
  await load({data:input.status});assert.equal(stale(),true,'Old cached snapshots are not fresh observations');
  assert.match(text('data-alert'),/snapshot is stale/);
  await load({data:fresh()});assert.equal(stale(),false);
  const old=fresh();old.generated_at=new Date(clock-1000).toISOString();await load({data:old});
  assert.match(text('data-alert'),/Out-of-order/);
  const absent=fresh();absent.plan={nav_estimate:999999,sleeves:{b3:{'US.SPY':999}}};absent.live=null;absent.vote_signals={status:'stale'};
  await load({data:absent});assert.match(text('nav-summary'),/Awaiting account observation/);assert.ok(!text('sleeves').includes('999999'));
  assert.match(text('vote-note'),/stale/);
  assert.doesNotMatch(text('vote-cards'), /Short signal/);
  absent.config.risk.legacy_exit_only = true;
  absent.broker_observation = {
    status:'verified', at:absent.generated_at, cash:95000, nav:100000,
    positions:{'US.XLP':21,'US.XLV':11}, market_values:{'US.XLP':2500,'US.XLV':2500}
  };
  await load({data:absent});
  assert.match(text('access-summary'), /Competition account verified/);
  assert.equal(text('vote-book'), '$100,000 sizing book');                // H retired 2026-11-26: its $20k moved here
  assert.ok(absent.config.execution_enabled);
  assert.equal(text('mode-badge'), 'Two-vote entries enabled in config');
  assert.match(text('sleeves'), /XLP21 long.*XLV11 long/);
  assert.match(text('sleeves'), /Sleeve attribution unavailable/);
  assert.equal(text('nav-summary'), '$100,000.00');
  assert.equal(text('cash-summary'), '$95,000.00');
  absent.broker_observation.status='unavailable';
  await load({data:absent});
  assert.match(text('sleeves'), /Stale.*XLP21 long.*XLV11 long/);
  assert.match(text('access-summary'), /Competition broker read unavailable/);
  absent.config.risk.entry_sleeves = ['h_etf'];                          // the pre-retirement H sleeve
  absent.config.h_etf.initial_allocation_usd = 20000;
  await load({data:absent});
  assert.match(text('sleeves'), /H ETF sleeve.*\$20,000.00 allocation/);
  assert.match(text('mode-badge'), /H entries enabled/);
  assert.match(text('vote-budget'), /\$20,000.00 per position · positions added up to the per-ticker cap · \$40,000.00 cap per ticker \(at most 39.5% of NAV\) · Longs are never sold at a loss/);
  assert.doesNotMatch(text('vote-budget'), /Saved for the next session/);
  absent.config_pending = {two_vote: {entry_usd: 30000, max_lots_per_symbol: 1, take_profit_usd: 150}};
  await load({data:absent});
  assert.match(text('vote-budget'), /\$20,000.00 per position.*Saved for the next session start: \$30,000.00 per position, 1 position per ticker, \$150.00 target$/);
  absent.config_pending = {};
  await load({data:absent});
  const voteHolding = fresh();
  voteHolding.config.two_vote.take_profit_usd = 100;                      // live config has none; exercise the display
  voteHolding.config.risk.legacy_exit_only = true;
  voteHolding.config.risk.entry_sleeves = ['h_etf','two_vote'];
  voteHolding.vote_signals = {status:'stale'};
  voteHolding.broker_observation = {
    status:'verified', at:voteHolding.generated_at, cash:91000, nav:100000,
    positions:{'US.QQQ':15}, market_values:{'US.QQQ':9000}
  };
  voteHolding.live.sleeves.two_vote = {'US.QQQ':15};
  voteHolding.live.take_profit_counts = {two_vote:{'US.SPY':2,'US.QQQ':3},h_etf:{'US.XLV':1}};
  await load({data:voteHolding});
  assert.match(text('vote-cards'), /QQQ.*Paper position15 long.*Verified by Moomoo.*\$9,000.00/);
  assert.match(text('vote-cards'), /SPY.*\$100.00 profit triggers2.*QQQ.*\$100.00 profit triggers3/);
  const noTarget = structuredClone(voteHolding); noTarget.config.two_vote.take_profit_usd = null;
  await load({data:noTarget});
  assert.doesNotMatch(text('vote-cards'), /profit triggers/);
  await load({data:voteHolding});
  assert.match(text('sleeves'), /Profit triggers1.*New entry size\$10,000.00.*\$20.00 profit target/);
  assert.doesNotMatch(text('sleeves'), /QQQ|Sleeve attribution unavailable/);
  voteHolding.live.sleeves.h_etf = {'US.QQQ':5};
  voteHolding.live.sleeves.two_vote = {'US.QQQ':10};
  await load({data:voteHolding});
  assert.match(text('vote-cards'), /QQQ.*Paper position10 long.*\$6,000.00/);
  assert.match(text('sleeves'), /QQQ5 long.*\$3,000.00/);
  assert.match(text('sleeves'), /\$5.00 profit target/);
  voteHolding.live.sleeves = {};
  await load({data:voteHolding});
  assert.doesNotMatch(text('vote-cards'), /Paper position/);
  assert.match(text('sleeves'), /Sleeve attribution unavailable.*QQQ15 long/);
  const exitOnly = fresh();
  exitOnly.config.risk.legacy_exit_only = true;
  exitOnly.config.risk.entry_sleeves = [];
  exitOnly.live.sleeves.h_etf = {'US.XLV':11, 'US.XLP':9};
  exitOnly.live.h_plan = {asof: '2026-11-19', entries:['US.DIA'], exits:{'US.XLV':'max_hold'}};
  await load({data:exitOnly});
  assert.equal(get('sleeves').children.length, 1);
  assert.match(text('sleeves'),/Legacy holdings/);
  assert.match(text('sleeves'),/Exit only.*XLV.*Sell at next open/);
  assert.match(text('sleeves'),/XLP/);
  assert.doesNotMatch(text('sleeves'),/DIA/);
  exitOnly.live.sleeves.h_etf = {};
  await load({data:exitOnly});
  assert.match(text('sleeves'),/No legacy positions recorded/);
  assert.equal(get('sleeves').hidden,false);
  exitOnly.account_snapshot = {at: exitOnly.generated_at, positions: {}, cash: 100000};
  exitOnly.runtime.mark_status = 'recent';
  await load({data:exitOnly});
  assert.equal(get('sleeves').hidden,true);
  exitOnly.account_snapshot.at = new Date(clock - 180000).toISOString();
  await load({data:exitOnly});
  assert.equal(get('sleeves').hidden,false);
  for (const request of requests) { assert.equal(request.url,'/api/competition');assert.ok(!request.options.method||request.options.method==='GET'); }
  console.log('Competition DOM behaviors passed');
})().catch(error => { console.error(error); process.exitCode = 1; });
'''


def test_competition_dom_status_fills_research_and_failures(tmp_path, monkeypatch):
    from dual_strategy.competition import report
    from dual_strategy.competition.planner import new_state
    from dual_strategy.competition.store import Store, load_config

    node = shutil.which('node')
    assert node is not None, 'Node is required for the competition DOM regression test'
    (tmp_path / 'config').mkdir()
    shutil.copyfile(Path(__file__).resolve().parents[1] / 'config' / 'competition.yaml', tmp_path / 'config' / 'competition.yaml')
    cfg = load_config(tmp_path)
    store = Store(tmp_path, {**cfg, 'state_dir': 'private/competition/live'})
    state = new_state()
    state['h_plan'] = {'asof': '2026-11-19', 'entries': ['US.XLV', 'US.XLP'], 'exits': {}}
    store.save(state)
    monkeypatch.setattr(report, '_process', lambda project: {'status': 'running', 'count': 1})
    status = report.competition_payload(tmp_path, datetime.fromisoformat('2026-11-20T13:00:00+00:00'))
    status['config']['risk']['legacy_exit_only'] = False
    status['vote_signals'] = {
        'status': 'current', 'bar_end': '2026-11-20T14:40:00+00:00', 'required_votes': 2,
        'tickers': {'US.SPY': {'buy': 0, 'sell': 2, 'signal': -1, 'entry_window': True,
                              'rules': {'Donchian': -1, 'Noise-area': -1}},
                    'US.QQQ': {'buy': 1, 'sell': 0, 'signal': 0, 'entry_window': True,
                              'rules': {'Donchian': 1}}}}
    parser = AssetParser()
    parser.feed((ASSETS / 'competition.html').read_text(encoding='utf-8'))
    payload = {'app': str(ASSETS / 'competition.js'), 'status': status,
               'ids': [attrs['id'] for _, attrs in parser.tags if 'id' in attrs]}
    result = subprocess.run([node, '-e', COMPETITION_DOM], input=json.dumps(payload), text=True,
                            encoding='utf-8', capture_output=True, timeout=20)
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'Competition DOM behaviors passed' in result.stdout


def test_vote_activity_counts_each_rule_switching_on(tmp_path):
    from dual_strategy.competition.report import _vote_activity
    from dual_strategy.competition.store import Store, load_config

    (tmp_path / 'config').mkdir()
    shutil.copyfile(Path(__file__).resolve().parents[1] / 'config' / 'competition.yaml', tmp_path / 'config' / 'competition.yaml')
    cfg = load_config(tmp_path)
    store = Store(tmp_path, {**cfg, 'state_dir': 'private/competition/live'})

    def step(session, slot, spy, qqq, mode='EXECUTE', name=None):
        folder = store.dir / 'audit' / session
        folder.mkdir(parents=True, exist_ok=True)
        hh, mm = divmod(9 * 60 + 30 + 5 * slot, 60)
        row = lambda rules: {'buy': sum(v > 0 for v in rules.values()), 'sell': sum(v < 0 for v in rules.values()),
                             'rules': rules, 'entry_window': True,
                             'signal': 1 if sum(v > 0 for v in rules.values()) >= 2 else -1 if sum(v < 0 for v in rules.values()) >= 2 else 0}
        record = {'kind': 'vote_step', 'session': session, 'mode': mode, 'slot': slot,
                  'bar_end': f'{session}T{hh:02d}:{mm:02d}:00-05:00', 'votes': {'US.SPY': row(spy), 'US.QQQ': row(qqq)}}
        (folder / (name or f'{mode}-{slot}.json')).write_text(json.dumps(record), encoding='utf-8')

    off = {'Donchian': 0, 'MACD': 0, 'Noise-area': 0}
    step('2026-11-23', 15, {**off, 'Donchian': 1}, {'Donchian': 0, 'MACD': 0})          # already on at first record
    step('2026-11-23', 16, {**off, 'Donchian': 1, 'MACD': 1}, {'Donchian': 0, 'MACD': -1})
    step('2026-11-23', 17, {**off, 'Donchian': -1, 'MACD': 1}, {'Donchian': 0, 'MACD': 0})  # flip counts again
    step('2026-11-24', 6, off, {'Donchian': 0, 'MACD': 0})
    step('2026-11-24', 7, {**off, 'Noise-area': -1}, {'Donchian': 1, 'MACD': 0})
    step('2026-11-24', 8, {**off, 'Noise-area': -1}, {'Donchian': 1, 'MACD': 0})            # still on: no new fire
    step('2026-11-24', 9, {**off, 'Donchian': 1}, {'Donchian': 1, 'MACD': 0}, mode='PLAN')  # PLAN records ignored
    (store.dir / 'audit' / '2026-11-24' / 'partial.json').write_text('{"kind": "vote', encoding='utf-8')

    act = _vote_activity(store, '2026-11-24')
    rules = {r['rule']: r for r in act['rules']}
    assert [r['rule'] for r in act['rules']][:10] == ['Donchian', 'Keltner', 'RSI(2)', 'MACD', 'DMI/ADX', 'Stochastic',
                                                       'Chandelier', 'Turtle Soup', 'NR7', 'Noise-area']
    assert act['status'] == 'incomplete'
    assert (rules['Donchian']['total'], rules['Donchian']['today']) == (3, 1)
    assert [(f['symbol'], f['side'], f['slot'], f['first_observed']) for f in rules['Donchian']['fires']] == [
        ('US.SPY', 'BUY', 15, True), ('US.SPY', 'SELL', 17, False), ('US.QQQ', 'BUY', 7, False)]
    assert [(f['symbol'], f['side']) for f in rules['MACD']['fires']] == [('US.QQQ', 'SELL'), ('US.SPY', 'BUY')]
    assert (rules['Noise-area']['total'], rules['Noise-area']['fires'][0]['bar_end']) == (1, '2026-11-24T10:05:00-05:00')
    assert rules['Keltner'] == {'rule': 'Keltner', 'today': 0, 'total': 0, 'fires': []}
    assert [(s['session'], s['symbol'], s['side'], s['slot']) for s in act['signals']] == [('2026-11-23', 'US.SPY', 'BUY', 16)]
    assert act['sessions']['2026-11-23'] == {'first_bar': '2026-11-23T10:45:00-05:00', 'last_bar': '2026-11-23T10:55:00-05:00', 'bars': 3}
    assert act['sessions']['2026-11-24']['bars'] == 3


def test_open_positions_show_entry_price_cost_mark_and_profit_exit():
    from dual_strategy.competition.report import _open_positions

    performance = {
        'trades': [
            {'sleeve': 'two_vote', 'symbol': 'US.QQQ', 'action': 'short', 'intent_id': '2026-11-24-two_vote-e12-QQQ-SELL',
             'ordered_at': '2026-11-24T10:30:18-05:00'},
            {'sleeve': 'h_etf', 'symbol': 'US.XLV', 'action': 'buy', 'intent_id': 'h1', 'ordered_at': '2026-11-20T09:30:35-05:00'}],
        'sleeves': {
            'two_vote': {'positions': {'US.QQQ': {'qty': -15, 'cost_basis': -9523.125, 'mark_price': 635.9}},
                         'entry_lots': {'US.QQQ': [{'id': 'audit:2026-11-24-two_vote-e12-QQQ-SELL', 'shares': 15,
                                                    'entry_price': 634.875, 'side': -1}]}},
            'h_etf': {'positions': {'US.XLV': {'qty': 11, 'cost_basis': 1968.45, 'mark_price': None},
                                    'US.XLP': {'qty': 0, 'cost_basis': 0.0}}}}}
    cfg = {'two_vote': {'take_profit_usd': 50}, 'h_etf': {'take_profit_usd': 20, 'legacy_take_profit_usd': 5}}
    rows = _open_positions(performance, cfg, {'h_take_profit_targets': {}})
    assert rows[0] == {'sleeve': 'two_vote', 'symbol': 'US.QQQ', 'qty': -15, 'side': 'short', 'entry_price': 634.875,
                       'cost': pytest.approx(9523.125), 'opened_at': '2026-11-24T10:30:18-05:00', 'mark_price': 635.9,
                       'value': pytest.approx(9538.5), 'unrealized_gross': pytest.approx(-15.375),
                       'take_profit_usd': 50, 'take_profit_price': pytest.approx(631.5417), 'sell_floor_price': None}
    xlv = rows[1]
    assert (xlv['symbol'], xlv['side'], xlv['entry_price'], xlv['opened_at']) == ('US.XLV', 'long', pytest.approx(178.95),
                                                                               '2026-11-20T09:30:35-05:00')
    assert xlv['mark_price'] is None and xlv['unrealized_gross'] is None and xlv['value'] is None
    assert (xlv['take_profit_usd'], xlv['take_profit_price']) == (5, pytest.approx(179.4045))   # legacy $5 target
    assert len(rows) == 2                                                                        # flat XLP skipped
    rows = _open_positions(performance, cfg, {'h_take_profit_targets': {'US.XLV': 20}})
    assert rows[1]['take_profit_price'] == pytest.approx(180.7682)
    # risk.long_sales_only_at_profit: each long shows the lowest quote it may be sold at (net > $0 after fees);
    # shorts have no floor (they may be covered at a loss).
    cfg['risk'] = {'long_sales_only_at_profit': True, 'limit_offset_bps': 5, 'min_long_sale_net_usd': 0.0}
    rows = _open_positions(performance, cfg, {'h_take_profit_targets': {}})
    assert rows[0]['sell_floor_price'] is None and rows[1]['sell_floor_price'] == 179.23


def test_dashboard_shows_the_running_runners_settings_not_the_edited_file(tmp_path, monkeypatch):
    from dual_strategy.competition import report
    from dual_strategy.competition.planner import new_state
    from dual_strategy.competition.store import Store, load_config

    (tmp_path / 'config').mkdir()
    shutil.copyfile(Path(__file__).resolve().parents[1] / 'config' / 'competition.yaml', tmp_path / 'config' / 'competition.yaml')
    cfg = load_config(tmp_path)
    store = Store(tmp_path, {**cfg, 'state_dir': 'private/competition/live'})
    store.save(new_state())
    now = datetime.fromisoformat('2026-11-24T17:00:00+00:00')
    session = '2026-11-24'
    old = {**cfg, 'two_vote': {**cfg['two_vote'], 'entry_usd': 10000, 'max_lots_per_symbol': 4, 'take_profit_usd': 50},
           'risk': {**cfg['risk'], 'halt_drawdown_fraction': 0.035}}
    pid = 'provenance/' + 'a' * 32
    (store.dir / 'audit' / 'provenance').mkdir(parents=True)
    (store.dir / 'audit' / f'{pid}.json').write_text(json.dumps({'kind': 'provenance', 'config': old}), encoding='utf-8')
    (store.dir / 'audit' / session).mkdir(parents=True)
    (store.dir / 'audit' / session / 'risk.json').write_text(json.dumps({'kind': 'risk', 'provenance_id': pid}), encoding='utf-8')

    monkeypatch.setattr(report, '_process', lambda project: {'status': 'running', 'count': 1})
    status = report.competition_payload(tmp_path, now)
    assert status['config_source'] == 'running runner'
    assert (status['config']['two_vote']['take_profit_usd'], status['config']['risk']['halt_drawdown_fraction']) == (50, 0.035)
    assert status['config_pending']['two_vote']['take_profit_usd'] is cfg['two_vote']['take_profit_usd'] is None
    monkeypatch.setattr(report, '_process', lambda project: {'status': 'stopped', 'count': 0})
    status = report.competition_payload(tmp_path, now)
    assert status['config_source'] == 'config file' and status['config_pending'] == {}
    assert status['config']['two_vote']['take_profit_usd'] is None
    (store.dir / 'audit' / session / 'risk.json').write_text(json.dumps({'provenance_id': '../../etc/passwd'}), encoding='utf-8')
    assert report._runner_config(store, session) is None
