"""Read-only competition dashboard observations; no broker calls or state writes."""

from __future__ import annotations

import json
import math
import re
import subprocess
import sys
from collections import Counter
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from pathlib import Path

from dual_strategy.competition.planner import break_even_quote, loss_guard
from dual_strategy.competition.signals import b3_decision_times
from dual_strategy.competition.store import MANUAL_FILL, Store, load_config, sleeve_performance
from dual_strategy.data.calendar import NY, next_session_open, session_bounds
from dual_strategy.reporting.service import redacted

SAFE_KEYS = ("initial_nav", "high_water", "last_nav", "last_mark_at", "day", "day_start_nav", "halted", "locked_day",
             "reduced", "orders_today", "order_errors_today", "sleeves", "h_entry_session", "h_plan", "h_plan_audit_id",
             "intraday", "nav_mismatch", "take_profit_counts", "take_profit_pending", "h_take_profit_targets")
REGIME_ROWS = {"10 Noise-area momentum": "noise", "2 VWAP trend continuation": "vwap", "1 ORB breakout/breakdown": "orb"}


def _regime_research(project: Path) -> list[dict]:
    """summary.csv rows for Noise-area, VWAP and ORB: hypothetical fills, $100,000 book, weekly P&L (named, not numbered)."""
    import csv
    path = project / "reports" / "claude_regime" / "results" / "summary.csv"
    if not path.exists():
        return []
    out = []
    with path.open(encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            if row["strategy"] in REGIME_ROWS:
                f = lambda k: float(row[k]) if row.get(k) not in (None, "") else None
                out.append({"sleeve": REGIME_ROWS[row["strategy"]], "strategy": row["strategy"].split(" ", 1)[1],
                            "settings": row["picked_params"],
                            "train_2021_24_week": f("picked_train_week"), "test_2025_26_week": f("picked_test_week"),
                            "test_winning_weeks_pct": f("picked_test_pos_weeks_pct"), "test_worst_week": f("picked_test_worst_week"),
                            "vix30_week": f("picked_vix30_week"), "last_week": f("picked_last_week"),
                            "trades_per_week": f("picked_trades_per_week")})
    return out


def _vote_signals(project: Path, cfg: dict, now: datetime) -> dict:
    path = project / cfg["state_dir"] / "vote_signals.json"
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
        if report["schema_version"] != 1:
            return {"status": "unavailable"}
        age = (now - datetime.fromisoformat(report["observed_at"])).total_seconds()
        if not -5 <= age <= 60:
            return {"status": "stale"}
        status = report["status"]
        if status not in ("current", "waiting", "preopen", "closed", "unavailable"):
            return {"status": "unavailable"}
        if status == "current":
            bar = datetime.fromisoformat(report["bar_end"])
            bounds = session_bounds(now)
            if (not bounds or not bounds[0] < bar <= now < bounds[1] or
                    (bar - bounds[0]).total_seconds() % 300 != 0 or (now - bar).total_seconds() > 360):
                return {"status": "stale"}
            threshold = cfg.get("two_vote", {}).get("required_votes", 2)
            tickers = report["tickers"]
            if (type(threshold) is not int or threshold < 1 or report["required_votes"] != threshold
                    or set(tickers) != {"US.SPY", "US.QQQ"}):
                return {"status": "unavailable"}
            for row in tickers.values():
                votes = row["rules"].values()
                if not votes or any(type(v) is not int or v not in (-1, 0, 1) for v in votes):
                    return {"status": "unavailable"}
                buy, sell = sum(v == 1 for v in votes), sum(v == -1 for v in votes)
                direction = int(buy >= threshold) - int(sell >= threshold)
                reported = row["buy"], row["sell"], row["signal"]
                if (any(type(value) is not int for value in reported) or reported != (buy, sell, direction)
                        or type(row["entry_window"]) is not bool):
                    return {"status": "unavailable"}
        return report
    except FileNotFoundError:
        return {"status": "waiting"}
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return {"status": "unavailable"}


def _summary(state: dict | None, cfg: dict, now: datetime) -> dict | None:
    if state is None:
        return None
    out = {k: state.get(k) for k in SAFE_KEYS}
    hw, nav = state.get("high_water"), state.get("last_nav")
    out["nav_estimate"] = nav
    out["halt_level"] = round(hw * (1 - cfg["risk"]["halt_drawdown_fraction"]), 2) if hw else None
    out["drawdown_pct"] = round(100 * (nav / hw - 1), 3) if nav and hw else None
    out["locked_today"] = state.get("locked_day") == now.astimezone(NY).date().isoformat()
    out["events"] = (state.get("events") or [])[-20:]
    return out


def _clean(x):
    if isinstance(x, float) and not math.isfinite(x):
        return None
    if isinstance(x, dict):
        return {k: ("Recorded error; inspect the private runner log." if k in ("error", "blocked") and v
                    else "Order error; human reconciliation required." if k == "reason" and isinstance(v, str) and v.startswith("order error:")
                    else _clean(v)) for k, v in redacted(x).items() if k != "order_id"}
    if isinstance(x, list):
        return [_clean(v) for v in x]
    return x


def _process(project: Path) -> dict:
    script = re.escape(str(project.resolve() / "scripts/run_competition.py"))
    windows = sys.platform == "win32"
    flags = re.IGNORECASE if windows else 0
    runner = re.compile(rf'(?:^|\s)"?{script}"?\s+loop\s+.*?(?<!\S)--execute(?:\s|$)', flags)
    python = re.compile(r'^(?:"[^"]*[\\/]python[^"\\/]*"|(?:\S*[\\/])?python[^\s\\/]*)\s', flags)
    unknown = {"status": "unknown", "count": None}
    try:
        command = [
            "powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
            "$ErrorActionPreference='Stop'; "
            "ConvertTo-Json -Compress -InputObject @(Get-CimInstance Win32_Process "
            "-Filter \"Name LIKE 'python%'\" | Select-Object ProcessId,ParentProcessId,CommandLine)",
        ] if windows else ["ps", "-axo", "pid=,stat=,args="]
        result = subprocess.run(command, capture_output=True, text=True, timeout=3,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if result.returncode:
            return unknown
        if windows:
            rows = json.loads(result.stdout)
            if any(row["CommandLine"] is None for row in rows):
                return unknown
            matches = [row for row in rows if python.match(row["CommandLine"]) and runner.search(row["CommandLine"])]
            # A Windows venv redirector and its Python child are one execution loop.
            count = len({row["ProcessId"] for row in matches} - {row["ParentProcessId"] for row in matches})
        else:
            rows = [row.split(maxsplit=2) for row in result.stdout.splitlines()]
            count = sum(len(row) == 3 and "Z" not in row[1] and python.match(row[2]) is not None
                        and runner.search(row[2]) is not None for row in rows)
        return {"status": "running" if count == 1 else "multiple" if count > 1 else "stopped", "count": count}
    except (OSError, subprocess.TimeoutExpired, ValueError, KeyError, TypeError):
        return unknown


def _runtime(project: Path, state: dict | None, cfg: dict, now: datetime) -> dict:
    bounds = session_bounds(now)
    schedule = []
    opened, closed = bounds if bounds else (None, None)
    next_open = next_session_open(now)
    if bounds:
        schedule = [{"at": opened + timedelta(seconds=10), "label": "H open orders"}]
        schedule += [{"at": t + timedelta(seconds=15), "label": "B3 decision"}
                     for t in b3_decision_times(opened, closed, cfg["b3"]["decision_times"])]
        schedule += [{"at": closed - timedelta(minutes=cfg["b3"]["flatten_minutes_before_close"]), "label": "B3 flatten"},
                     {"at": closed, "label": "Market close"},
                     {"at": closed + timedelta(minutes=15), "label": "Next-session H plan"}]
    next_action = next((s for s in schedule if s["at"] > now), None)
    age, mark_status = None, "not_recorded"
    mark = (state or {}).get("last_mark_at")
    if mark:
        age = (now - datetime.fromisoformat(mark)).total_seconds()
        mark_status = "clock_mismatch" if age < 0 else "stale" if age > 120 else "recent"
    return {"process": _process(project), "market_phase": "closed" if not bounds or now >= closed else "preopen" if now < opened else "open",
            "next_open": next_open.isoformat() if next_open else None,
            "session_open": opened.isoformat() if opened else None, "session_close": closed.isoformat() if closed else None,
            "schedule": [{**s, "at": s["at"].isoformat()} for s in schedule],
            "next_action": {**next_action, "at": next_action["at"].isoformat()} if next_action else None,
            "mark_status": mark_status, "mark_age_seconds": age, "mark_at": mark}


def _orders(rows: list[dict]):
    intents, acknowledged, outcomes = {}, set(), {}
    errors, refused = set(), set()
    for row in rows:
        key = (row.get("audit_id"), row.get("intent_id"))
        event = row.get("event")
        if event == "intent":
            intents[key] = {**row, "status": "PLANNED" if row.get("mode") == "PLAN" else "UNCONFIRMED", "filled": None, "avg_price": None}
        elif event == "acknowledged":
            acknowledged.add(row["order_id"])
            if key in intents:
                intents[key]["status"] = "ACKNOWLEDGED"
        elif event == "outcome":
            outcomes[row["order_id"]] = row
            if key in intents:
                intents[key].update({k: row.get(k) for k in ("status", "filled", "avg_price")})
                intents[key]["recorded_source"] = "manual" if row.get("source") == MANUAL_FILL else "automatic"
                intents[key]["source_evidence"] = row.get("source")
        elif event == "order_error":
            errors.add(key)
            if key in intents:
                intents[key]["has_error"] = True
                if intents[key]["status"] not in ("REJECTED", "FILLED", "CANCELLED"):
                    intents[key]["status"] = "ERROR"
        elif event == "order_refused":
            refused.add(key)
            if key in intents:
                intents[key]["status"] = "REFUSED"
    counts = {"acknowledged": len(acknowledged), "filled": 0, "partial": 0, "rejected": 0, "cancelled": 0,
              "errors": len(errors), "refused": len(refused)}
    for row in outcomes.values():
        status = row.get("status", "").lower()
        if status in ("filled", "rejected", "cancelled"):
            counts[status] += 1
        if 0 < row.get("filled", 0) < row.get("qty", 0):
            counts["partial"] += 1
    return list(intents.values()), counts


@lru_cache(maxsize=1024)
def _audit_summary(path: Path, mtime_ns: int, size: int) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    return {k: data.get(k) for k in ("kind", "mode", "logged_at", "audit_id", "account", "state_after", "decision", "reason", "error")}


def _observations(store: Store, session: str):
    equity, accounts, decisions, warnings = [], [], [], []
    for path in (store.dir / "audit" / session).glob("[!.]*.json"):
        try:
            stat = path.stat()
            data = _audit_summary(path, stat.st_mtime_ns, stat.st_size)
        except (OSError, ValueError):
            warnings.append("An audit snapshot is unreadable or still being written; displayed evidence is incomplete.")
            continue
        if data.get("mode") != "EXECUTE":
            continue
        account = data.get("account")
        if account and account.get("at"):
            accounts.append(account)
        if data.get("kind") == "risk":
            state = data.get("state_after") or {}
            nav, hw, at = state.get("last_nav"), state.get("high_water"), state.get("last_mark_at")
            if at and nav is not None and hw:
                equity.append({"at": at, "nav": nav, "drawdown_pct": round(100 * (nav / hw - 1), 6)})
        if data.get("kind") == "b3" and data.get("decision"):
            decisions.append({**data["decision"], "audit_id": data["audit_id"], "plan_reason": data["reason"]})
    equity.sort(key=lambda p: p["at"])
    return {"equity": equity, "account_snapshot": max(accounts, key=lambda a: a["at"]) if accounts else None,
            "b3_decision": max(decisions, key=lambda d: d["at"]) if decisions else None,
            "evidence_warnings": list(dict.fromkeys(warnings))}


VOTE_RULES = ("Donchian", "Keltner", "RSI(2)", "MACD", "DMI/ADX", "Stochastic", "Chandelier", "Turtle Soup", "NR7",
              "Noise-area")
_VOTE_STEPS: dict[tuple, dict | None] = {}


def _vote_step(path: Path, mtime_ns: int, size: int) -> dict | None:
    """The per-bar votes of one EXECUTE vote_step audit record (None for any other record). Cached per file version."""
    key = (str(path), mtime_ns, size)
    if key not in _VOTE_STEPS:
        data = json.loads(path.read_text(encoding="utf-8"))
        keep = None
        if data.get("kind") == "vote_step" and data.get("mode") == "EXECUTE":
            keep = {"slot": data["slot"], "bar_end": data["bar_end"],
                    "votes": {symbol: {"rules": dict(row["rules"]), "signal": row.get("signal")}
                              for symbol, row in data["votes"].items()}}
        _VOTE_STEPS[key] = keep
    return _VOTE_STEPS[key]


def _vote_steps(store: Store) -> tuple[dict[str, list[dict]], bool]:
    """The runner's per-bar votes by session, ordered by slot; True when some audit record was unreadable."""
    by_session, incomplete = {}, False
    for directory in sorted((store.dir / "audit").glob("????-??-??")):
        steps = []
        for path in directory.glob("[!.]*.json"):
            try:
                stat = path.stat()
                step = _vote_step(path, stat.st_mtime_ns, stat.st_size)
            except (OSError, ValueError, KeyError, TypeError, AttributeError):
                incomplete = True
                continue
            if step and type(step["slot"]) is int:
                steps.append(step)
        if steps:
            by_session[directory.name] = sorted(steps, key=lambda s: s["slot"])
    return by_session, incomplete


def _trade_rules(trades: list[dict], by_session: dict[str, list[dict]]) -> None:
    """Name the rules behind each Two-vote signal trade (intent ids carry the slot as -e<slot>-)."""
    for trade in trades:
        match = re.search(r"-e(\d+)-", trade.get("intent_id") or "")
        if trade.get("sleeve") != "two_vote" or not match:
            continue
        step = next((s for s in by_session.get(trade["session"], []) if s["slot"] == int(match.group(1))), None)
        rules = ((step or {}).get("votes", {}).get(trade["symbol"]) or {}).get("rules")
        if rules:
            side = 1 if trade["side"] == "BUY" else -1
            trade["rules"] = [name for name, vote in rules.items() if vote == side]


_PROVENANCE_CONFIG: dict[str, dict | None] = {}


def _runner_config(store: Store, session: str) -> dict | None:
    """The config the runner that audited this session actually loaded (from its provenance record), or None.
    Config edits only take effect when a runner starts, so the dashboard must show what is running, not the file."""
    newest, newest_ns = None, -1
    for path in (store.dir / "audit" / session).glob("[!.]*.json"):
        try:
            mtime = path.stat().st_mtime_ns
        except OSError:
            continue
        if mtime > newest_ns:
            newest, newest_ns = path, mtime
    if newest is None:
        return None
    try:
        pid = json.loads(newest.read_text(encoding="utf-8")).get("provenance_id")
        if not isinstance(pid, str) or not re.fullmatch(r"provenance/[0-9a-f]{32}", pid):
            return None
        if pid not in _PROVENANCE_CONFIG:
            record = json.loads((store.dir / "audit" / f"{pid}.json").read_text(encoding="utf-8"))
            _PROVENANCE_CONFIG[pid] = record.get("config") if isinstance(record.get("config"), dict) else None
        return _PROVENANCE_CONFIG[pid]
    except (OSError, ValueError):
        return None


def _open_positions(performance: dict, cfg: dict, state: dict | None) -> list[dict]:
    """What is held now: one row per Two-vote entry lot (each has its own price and $ target), else one per position."""
    trades = performance.get("trades") or []
    opened_by_intent = {t["intent_id"]: t.get("ordered_at") for t in trades}

    def row(sleeve, symbol, qty, entry, opened_at, mark, target):
        finite_mark = type(mark) in (int, float) and math.isfinite(mark) and mark > 0
        return {"sleeve": sleeve, "symbol": symbol, "qty": qty, "side": "long" if qty > 0 else "short",
                "entry_price": entry, "cost": abs(qty) * entry, "opened_at": opened_at,
                "mark_price": mark if finite_mark else None,
                "value": abs(qty) * mark if finite_mark else None,
                "unrealized_gross": round(qty * (mark - entry), 8) if finite_mark else None,
                "take_profit_usd": target,
                # long: entry + target/shares; short: entry - target/shares (qty is negative)
                "take_profit_price": round(entry + target / qty, 4) if target else None,
                # risk.long_sales_only_at_profit: the lowest quote at which this long may be sold (net > 0 after fees)
                "sell_floor_price": break_even_quote(entry, qty, cfg) if qty > 0 and loss_guard(cfg) else None}

    rows = []
    for s, sleeve in (performance.get("sleeves") or {}).items():
        for symbol, p in (sleeve.get("positions") or {}).items():
            qty, mark = p.get("qty"), p.get("mark_price")
            if not qty:
                continue
            lots = (sleeve.get("entry_lots") or sleeve.get("ledger_lots") or {}).get(symbol) if s == "two_vote" else None
            if lots:
                for lot in lots:
                    rows.append(row(s, symbol, lot["shares"] * lot["side"], lot["entry_price"],
                                    opened_by_intent.get(lot["id"].split(":", 1)[-1]), mark,
                                    cfg.get("two_vote", {}).get("take_profit_usd")))
                continue
            target = None
            if s == "h_etf":
                h = cfg.get("h_etf", {})
                target = ((state or {}).get("h_take_profit_targets") or {}).get(
                    symbol, h.get("legacy_take_profit_usd", h.get("take_profit_usd")))
            opens = [t for t in trades if t["sleeve"] == s and t["symbol"] == symbol and t["action"] in ("buy", "short")]
            rows.append(row(s, symbol, qty, p["cost_basis"] / qty, opens[-1].get("ordered_at") if opens else None, mark,
                            target))
    return rows


def _vote_activity(store: Store, today: str, loaded: tuple | None = None) -> dict:
    """Each time a Two-vote rule switched on (to buy or sell short), from the runner's per-bar vote_step records."""
    by_session, incomplete = loaded or _vote_steps(store)
    fires, signals, sessions = [], [], {}
    for session, steps in by_session.items():
        sessions[session] = {"first_bar": steps[0]["bar_end"], "last_bar": steps[-1]["bar_end"], "bars": len(steps)}
        previous = {}
        for index, step in enumerate(steps):
            for symbol, row in sorted(step["votes"].items()):
                for rule, side in [*row["rules"].items(), (None, row["signal"])]:
                    if type(side) is not int or side not in (-1, 0, 1):
                        incomplete = True
                        continue
                    if side and side != previous.get((symbol, rule), 0):
                        fire = {"session": session, "symbol": symbol, "side": "BUY" if side > 0 else "SELL",
                                "bar_end": step["bar_end"], "slot": step["slot"], "first_observed": index == 0}
                        (signals if rule is None else fires).append({**fire, **({"rule": rule} if rule else {})})
                    previous[(symbol, rule)] = side
    names = [*VOTE_RULES, *sorted({f["rule"] for f in fires} - set(VOTE_RULES))]
    rules = [{"rule": name, "today": sum(f["session"] == today for f in fires if f["rule"] == name),
              "total": sum(f["rule"] == name for f in fires), "fires": [f for f in fires if f["rule"] == name]}
             for name in names]
    return {"status": "incomplete" if incomplete else "available", "today": today, "sessions": sessions,
            "rules": rules, "signals": signals}


def _observed_time(value, now):
    try:
        at = datetime.fromisoformat(value)
        return at if at.tzinfo is not None and at <= now else None
    except (TypeError, ValueError):
        return None


def _access_health(store: Store, state: dict | None, now: datetime) -> dict:
    # CLI auth status can refresh the shared token; use passive runner evidence instead.
    mark = _observed_time((state or {}).get("last_mark_at"), now)
    failures, incomplete = [], False
    try:
        records = []
        for path in sorted((store.dir / "outbox").glob("????-??-??.jsonl"))[-2:]:
            records.extend(store.outbox(path.stem))
        for directory in sorted((store.dir / "audit").glob("????-??-??"))[-2:]:
            for path in directory.glob("[!.]*.json"):
                try:
                    stat = path.stat()
                    record = _audit_summary(path, stat.st_mtime_ns, stat.st_size)
                    if record.get("mode") == "EXECUTE":
                        records.append(record)
                except (OSError, ValueError):
                    incomplete = True
        for record in records:
            error = record.get("error")
            if not error or record.get("mode") == "PLAN":
                continue
            at = _observed_time(record.get("logged_at"), now)
            if at is None:
                incomplete = True
            elif mark is None or at >= mark:
                auth = re.search(r'\[(AUTH_EXPIRED|AUTH_INVALID)\]|"code"\s*:\s*"(AUTH_EXPIRED|AUTH_INVALID)"', str(error))
                failures.append({"status": "sign_in_required" if auth else "check_required", "at": at.isoformat()})
    except (OSError, ValueError):
        incomplete = True
    if failures:
        return max(failures, key=lambda f: (f["status"] == "sign_in_required", f["at"]))
    recent = mark is not None and (now - mark).total_seconds() <= 120 and not incomplete
    return {"status": "recent_success" if recent else "unverified", "at": mark.isoformat() if mark else None}


def _startup_health(project: Path, process: dict, now: datetime) -> dict:
    directory = project / "private/competition/scheduler"
    empty = {"status": "not_recorded", "session": None, "at": None, "reason": None}
    records = []
    reasons = {"read_only_preflight_failed_twice", "persistent_safety_block", "prior_startup_requires_review",
               "process_probe_failed", "startup_window_elapsed", "session_already_touched",
               "competition_account_not_confirmed", "execution_gate_or_storage_changed", "persisted_capital_invalid",
               "prior_b3_position_not_flat", "prior_execution_error_requires_review", "state_changed_during_preflight",
               "runner_appeared_during_preflight"}
    try:
        for path in sorted(directory.glob("????-??-??.json")):
            record = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(record, dict):
                raise ValueError("Invalid startup record")
            at = _observed_time(record.get("at"), now)
            status = record.get("status")
            if (at is None or record.get("session") != path.stem or at.astimezone(NY).date().isoformat() != path.stem
                    or status not in ("blocked", "unexpected_exit", "preflight_started", "launched", "completed")):
                raise ValueError("Invalid startup observation")
            prior = path.stem < now.astimezone(NY).date().isoformat()
            if status != "completed" and prior:
                status = "blocked"
            elif status == "unexpected_exit":
                status = "blocked"
            elif status == "preflight_started":
                status = "checking" if (now - at).total_seconds() <= 900 else "blocked"
            elif status == "launched" and process["status"] != "running":
                status = "unverified" if process["status"] == "unknown" else "blocked"
            reason = record.get("reason")
            records.append({"status": status, "session": path.stem, "at": at.isoformat(),
                            "reason": reason if isinstance(reason, str) and reason in reasons else None})
        blocked = next((r for r in records if r["status"] == "blocked"), None)
        if blocked:
            return blocked
        log = directory / "launchd.log"
        if log.exists():
            with log.open("rb") as stream:
                stream.seek(max(0, log.stat().st_size - 8192))
                lines = stream.read().decode("utf-8", errors="replace").splitlines()
            if lines:
                last = json.loads(lines[-1])
                if not isinstance(last, dict):
                    raise ValueError("Invalid scheduler output")
                if last.get("status") in ("blocked", "unexpected_exit"):
                    return {**empty, "status": "blocked"}
        return records[-1] if records else empty
    except (OSError, ValueError):
        return {**empty, "status": "unverified"}


def competition_payload(project: Path, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    cfg = load_config(project)
    stores = {mode: Store(project, {**cfg, "state_dir": f"{cfg['state_dir']}/{mode}"}) for mode in ("live", "plan")}
    states = {m: (s.load() if s.path.exists() else None) for m, s in stores.items()}
    source = "live" if states["live"] is not None else "plan"
    store = stores[source]
    session = now.astimezone(NY).date().isoformat()
    rows = store.outbox(session)
    orders, counts = _orders(rows)
    preview_path = project / "reports" / "competition" / "backtest_preview.json"
    preview = json.loads(preview_path.read_text(encoding="utf-8")) if preview_path.exists() else None
    if preview:
        for k, w in preview["windows"].items():
            if k != "long":
                w.pop("equity", None)
    observations = _observations(stores["live"], session)
    runtime = _runtime(project, states["live"], cfg, now)
    votes = _vote_steps(stores["live"])
    performance = sleeve_performance(stores["live"], states["live"], observations["account_snapshot"], cfg)
    _trade_rules(performance.get("trades", []), votes[0])
    # While a runner is active, show the settings it loaded; edits to the file only apply at the next start.
    running = _runner_config(stores["live"], session) if runtime["process"]["status"] == "running" else None
    live_keys = ("two_vote", "h_etf", "risk")
    shown = {**cfg, **{k: running[k] for k in live_keys if isinstance((running or {}).get(k), dict)}}
    pending = {k: cfg[k] for k in live_keys if k in cfg and shown.get(k) != cfg[k]}
    return _clean({
        "generated_at": now.isoformat(),
        "config": {k: shown[k] for k in ("allocation", "b3", "h_etf", "noise", "vwap", "orb", "two_vote", "risk", "execution_enabled")
                   if k in shown},
        "config_source": "running runner" if running else "config file",
        "config_pending": pending,
        "live": _summary(states["live"], shown, now), "plan": _summary(states["plan"], cfg, now),
        "runtime": runtime, "access": _access_health(stores["live"], states["live"], now),
        "startup": _startup_health(project, runtime["process"], now),
        "outbox_source": "LIVE runner" if source == "live" else "PLAN runner (nothing sent)",
        "outbox_session": session, "outbox": rows[-200:], "orders": orders, "order_counts": counts,
        "step_errors": dict(Counter(r.get("step", "unknown") for r in rows if r.get("event") == "runner_error")),
        "step_skips": dict(Counter(r.get("step", "unknown") for r in rows if r.get("event") == "step_skipped")),
        "regime_research": _regime_research(project),
        "vote_signals": _vote_signals(project, cfg, now),
        "vote_activity": _vote_activity(stores["live"], session, votes),
        "performance": performance,
        "open_positions": _open_positions(performance, shown, states["live"]),
        **observations, "preview": preview,
    })
